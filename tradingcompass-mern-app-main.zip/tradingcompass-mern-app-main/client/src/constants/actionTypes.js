export const FETCH_ALL ='FETCH_ALL';
export const PLACE_ORDER = 'PLACE_ORDER';
export const UPDATE ='UPDATE';
export const DELETE = 'DELETE';
export const AUTH='AUTH';
export const LOGOUT='LOGOUT';
export const CLIENT_MSG='CLIENT_MSG';
export const REGISTRATION='REGISTRATION';
