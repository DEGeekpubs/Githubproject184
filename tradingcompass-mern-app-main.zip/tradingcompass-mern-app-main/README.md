# tradingcompass-MERN-optiondataVisualization-app

# Welcome to Trading Compass

Our goal is help traders providing rich data via Trading Compass. We created trading compass for the traders who want to make use of data for daily trading. This is a continuous effort to make it a great tool for everyone.

For any support or feedback, feel free to contact us

Details on this website is compiled for the convenience of site visitors and is furnished without responsibility for accuracy and is accepted by the site visitor on the condition that transmission or omissions shall not be made the basis for any claim, demand or cause for action. The information and data was obtained from sources believed to be reliable, but accuracy is not guaranteed.

# SignUp Form validation 

[![screencapture-tradingcompass-in-auth-2022-11-03-19-43-42.png](https://i.postimg.cc/y8BzK6hG/screencapture-tradingcompass-in-auth-2022-11-03-19-43-42.png)](https://postimg.cc/F7P6g4Bb)

# OTP Validation

[![screencapture-tradingcompass-in-otpauth-2022-11-03-19-46-48.png](https://i.postimg.cc/R0L7YdS8/screencapture-tradingcompass-in-otpauth-2022-11-03-19-46-48.png)](https://postimg.cc/jWCnwzJQ)

# features provided by trading compass

[![portfoliosample.jpg](https://i.postimg.cc/dVGVFJnt/portfoliosample.jpg)](https://postimg.cc/685XLJDD)

[![screencapture-tradingcompass-in-oi-intervalwise-2022-10-17-19-25-30.png](https://i.postimg.cc/Xvc0VGYC/screencapture-tradingcompass-in-oi-intervalwise-2022-10-17-19-25-30.png)](https://postimg.cc/jW51cjNx)

[![homepagesample.jpg](https://i.postimg.cc/D0277Gj2/homepagesample.jpg)](https://postimg.cc/34bsBkQ6)

[![sectorialsample.jpg](https://i.postimg.cc/prnJX9p6/sectorialsample.jpg)](https://postimg.cc/rRMrfwG1)

[![oisample.jpg](https://i.postimg.cc/D0Zyqsqx/oisample.jpg)](https://postimg.cc/mzvs4Pp9)
